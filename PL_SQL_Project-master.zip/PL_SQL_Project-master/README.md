# PL_SQL_Project
Software requirements: Oracle 10g, SQL*PLUS

SQL*Plus is a command line interface tool which is used to access Oracle databases. 
After installing Oracle 10g, you can find the SQL*PLUS command line using the following path:
C:\oraclexe\app\oracle\product\10.2.0\server\BIN

After launching it, enter username and password that you was set in the installation process. 
Normally we use system as username and the password during installation can be anything.

For the distribution part. You can use two or more Operating systems to access the tables and to manipulate them. 
You can install an OS in VMWare and then use it.
For establishing connection between two individual OS see the video https://www.youtube.com/watch?v=OAnh6H7NfTY&feature=youtu.be


