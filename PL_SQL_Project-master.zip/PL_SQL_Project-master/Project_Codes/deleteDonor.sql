id1 := '10';
	
delete from DONOR where DID=id1;
dbms_output.put_line('Data Deleted from All Tables');
