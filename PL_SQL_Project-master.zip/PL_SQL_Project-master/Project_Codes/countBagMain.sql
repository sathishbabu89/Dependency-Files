
bg := 'A+';
res := countBagNums(bg);
dbms_output.put_line('Total bags of blood group ' ||bg|| ' = '||res);
	
